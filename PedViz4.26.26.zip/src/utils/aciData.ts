import { BarData } from '../types/pedestal';

export const ACI_BARS: BarData[] = [
  { size: '#3', diameter: 0.375, area: 0.11 },
  { size: '#4', diameter: 0.500, area: 0.20 },
  { size: '#5', diameter: 0.625, area: 0.31 },
  { size: '#6', diameter: 0.750, area: 0.44 },
  { size: '#7', diameter: 0.875, area: 0.60 },
  { size: '#8', diameter: 1.000, area: 0.79 },
  { size: '#9', diameter: 1.128, area: 1.00 },
  { size: '#10', diameter: 1.270, area: 1.27 },
  { size: '#11', diameter: 1.410, area: 1.56 },
  { size: '#14', diameter: 1.693, area: 2.25 },
  { size: '#18', diameter: 2.257, area: 4.00 },
];

export const getBarData = (size: string): BarData => {
  return ACI_BARS.find((b) => b.size === size) || ACI_BARS[5]; // Default to #8
};

export const DEFAULT_INPUTS = {
  pedestalLength: 24,
  pedestalWidth: 24,
  pedestalHeight: 48,
  baseplateLength: 18,
  baseplateWidth: 18,
  baseplateThickness: 1.5,
  groutThickness: 1,
  verticalBarSize: '#8',
  tieBarSize: '#4',
  barsAlongLength: 4,
  barsAlongWidth: 4,
  clearance: 2.0,
  topTieClearance: 3.0,
  tieSpacing: 12,
  bolts: [
    { x: -6, y: -6 },
    { x: 6, y: -6 },
    { x: 6, y: 6 },
    { x: -6, y: 6 },
  ],
  boltTotalLength: 24,
  boltProjection: 4,
  boltDiameter: 1.0,
};
