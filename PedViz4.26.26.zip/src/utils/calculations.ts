import { PedestalInputs, CalculatedData } from '../types/pedestal';
import { getBarData } from './aciData';

export const calculatePedestalData = (inputs: PedestalInputs): CalculatedData => {
  const verticalBar = getBarData(inputs.verticalBarSize);
  const tieBar = getBarData(inputs.tieBarSize);
  const vRadius = verticalBar.diameter / 2;
  const tRadius = tieBar.diameter / 2;

  const verticalBars: { x: number; y: number; z: number }[] = [];
  const warnings: string[] = [];

  // Clearance is to the outer edge of the vertical bar.
  // Center position = (PedestalEdge - Clearance - vRadius)
  const xMax = inputs.pedestalLength / 2 - inputs.clearance - vRadius;
  const yMax = inputs.pedestalWidth / 2 - inputs.clearance - vRadius;

  // Bars along Length faces (spanning Length, so constant Y)
  // Includes corner bars
  const xStep = (2 * xMax) / (inputs.barsAlongLength - 1);
  for (let i = 0; i < inputs.barsAlongLength; i++) {
    const x = -xMax + i * xStep;
    verticalBars.push({ x, y: yMax, z: 0 });
    verticalBars.push({ x, y: -yMax, z: 0 });
  }

  // Bars along Width faces (spanning Width, so constant X)
  // Exclude corner bars to avoid duplicates
  const yStep = (2 * yMax) / (inputs.barsAlongWidth - 1);
  for (let i = 1; i < inputs.barsAlongWidth - 1; i++) {
    const y = -yMax + i * yStep;
    verticalBars.push({ x: xMax, y, z: 0 });
    verticalBars.push({ x: -xMax, y, z: 0 });
  }

  // Ties
  // Tie centerline inset by one tie-bar radius from the outer face of the vertical bars.
  // Outer face of vertical bar is at (xMax + vRadius)
  // Tie centerline is at (xMax + vRadius - tRadius)
  const tieWidth = 2 * (yMax + vRadius - tRadius);
  const tieLength = 2 * (xMax + vRadius - tRadius);

  const ties: { z: number; width: number; length: number }[] = [];
  let currentZ = inputs.pedestalHeight - inputs.topTieClearance;
  while (currentZ >= 0) {
    ties.push({ z: currentZ, width: tieWidth, length: tieLength });
    currentZ -= inputs.tieSpacing;
  }

  // Anchor bolt embedment
  const boltEmbedment = inputs.boltTotalLength - inputs.boltProjection - inputs.baseplateThickness - inputs.groutThickness;

  // Validations
  if (boltEmbedment <= 0) {
    warnings.push('Anchor bolt embedment is zero or negative.');
  }
  if (inputs.clearance < verticalBar.diameter) {
    warnings.push('Clearance is less than vertical bar diameter.');
  }
  inputs.bolts.forEach((bolt, idx) => {
    if (Math.abs(bolt.x) > inputs.pedestalLength / 2 || Math.abs(bolt.y) > inputs.pedestalWidth / 2) {
      warnings.push(`Bolt ${idx + 1} is outside the pedestal.`);
    }
  });

  return {
    verticalBars,
    ties,
    boltEmbedment,
    warnings,
  };
};
