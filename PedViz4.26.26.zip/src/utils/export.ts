import { jsPDF } from 'jspdf';
import { PedestalInputs, CalculatedData } from '../types/pedestal';
import { saveImageToDevice } from './mobileFeatures';

export const exportToPDF = (inputs: PedestalInputs, data: CalculatedData) => {
  const doc = new jsPDF();
  
  doc.setFontSize(20);
  doc.text('PedestalViz - Design Report', 20, 20);
  
  doc.setFontSize(12);
  doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 30);
  
  doc.setFontSize(14);
  doc.text('Input Parameters', 20, 45);
  doc.setFontSize(10);
  doc.text(`Pedestal: ${inputs.pedestalLength}" x ${inputs.pedestalWidth}" x ${inputs.pedestalHeight}"`, 20, 55);
  doc.text(`Baseplate: ${inputs.baseplateLength}" x ${inputs.baseplateWidth}" x ${inputs.baseplateThickness}"`, 20, 62);
  doc.text(`Grout: ${inputs.groutThickness}"`, 20, 69);
  doc.text(`Vertical Rebar: ${inputs.verticalBarSize} (${inputs.barsAlongLength}x${inputs.barsAlongWidth})`, 20, 76);
  doc.text(`Tie Rebar: ${inputs.tieBarSize} @ ${inputs.tieSpacing}" spacing`, 20, 83);
  doc.text(`Anchor Bolts: 4x ${inputs.boltDiameter}" dia, ${inputs.boltTotalLength}" length`, 20, 90);
  
  doc.setFontSize(14);
  doc.text('Calculated Results', 20, 105);
  doc.setFontSize(10);
  doc.text(`Anchor Bolt Embedment: ${data.boltEmbedment.toFixed(2)}"`, 20, 115);
  doc.text(`Number of Ties: ${data.ties.length}`, 20, 122);
  doc.text(`Tie Dimensions: ${data.ties[0]?.length.toFixed(2)}" x ${data.ties[0]?.width.toFixed(2)}"`, 20, 129);
  
  if (data.warnings.length > 0) {
    doc.setTextColor(255, 0, 0);
    doc.text('Warnings:', 20, 145);
    data.warnings.forEach((w, i) => {
      doc.text(`- ${w}`, 25, 152 + i * 7);
    });
  }
  
  doc.save('PedestalViz_Report.pdf');
};

export const captureAndSaveView = async (elementId: string, filename: string) => {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  // For SVG elements, we can convert to canvas then to dataURL
  if (element instanceof SVGSVGElement) {
    const svgData = new XMLSerializer().serializeToString(element);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    img.onload = async () => {
      canvas.width = element.viewBox.baseVal.width || element.clientWidth;
      canvas.height = element.viewBox.baseVal.height || element.clientHeight;
      ctx?.drawImage(img, 0, 0);
      const dataURL = canvas.toDataURL('image/png');
      await saveImageToDevice(dataURL, filename);
      URL.revokeObjectURL(url);
    };
    img.src = url;
  } else if (element instanceof HTMLCanvasElement) {
    // For 3D view canvas
    const dataURL = element.toDataURL('image/png');
    await saveImageToDevice(dataURL, filename);
  }
};
