import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { PedestalInputs, CalculatedData } from '../types/pedestal';
import { getBarData } from '../utils/aciData';
import { Maximize, Minimize, Camera, Eye, EyeOff } from 'lucide-react';

interface ThreeDViewProps {
  inputs: PedestalInputs;
  data: CalculatedData;
}

const ThreeDView: React.FC<ThreeDViewProps> = ({ inputs, data }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const [showConcrete, setShowConcrete] = useState(true);
  const [showRebar, setShowRebar] = useState(true);
  const [showBaseplate, setShowBaseplate] = useState(true);
  const [showBolts, setShowBolts] = useState(true);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf1f5f9);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(inputs.pedestalLength * 2, inputs.pedestalHeight, inputs.pedestalWidth * 2);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.domElement.id = 'three-canvas';
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controlsRef.current = controls;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(100, 100, 100);
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0xffffff, 0.5);
    pointLight.position.set(-100, 50, -100);
    scene.add(pointLight);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!containerRef.current || !camera || !renderer) return;
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  useEffect(() => {
    if (!sceneRef.current) return;

    const scene = sceneRef.current;
    // Clear previous objects
    while (scene.children.length > 0) {
      const obj = scene.children[0];
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) {
          obj.material.forEach(m => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
      scene.remove(obj);
    }

    // Add lights back
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(100, 100, 100);
    scene.add(directionalLight);

    // Concrete Pedestal
    if (showConcrete) {
      const geometry = new THREE.BoxGeometry(inputs.pedestalLength, inputs.pedestalHeight, inputs.pedestalWidth);
      const material = new THREE.MeshPhongMaterial({
        color: 0xcccccc,
        transparent: true,
        opacity: 0.4,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.y = inputs.pedestalHeight / 2;
      scene.add(mesh);

      // Edges
      const edges = new THREE.EdgesGeometry(geometry);
      const line = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x94a3b8 }));
      line.position.y = inputs.pedestalHeight / 2;
      scene.add(line);
    }

    // Grout
    const groutGeom = new THREE.BoxGeometry(inputs.pedestalLength, inputs.groutThickness, inputs.pedestalWidth);
    const groutMat = new THREE.MeshPhongMaterial({ color: 0xfef3c7 });
    const groutMesh = new THREE.Mesh(groutGeom, groutMat);
    groutMesh.position.y = inputs.pedestalHeight + inputs.groutThickness / 2;
    scene.add(groutMesh);

    // Baseplate
    if (showBaseplate) {
      const bpGeom = new THREE.BoxGeometry(inputs.baseplateLength, inputs.baseplateThickness, inputs.baseplateWidth);
      const bpMat = new THREE.MeshPhongMaterial({ color: 0x475569, shininess: 100 });
      const bpMesh = new THREE.Mesh(bpGeom, bpMat);
      bpMesh.position.y = inputs.pedestalHeight + inputs.groutThickness + inputs.baseplateThickness / 2;
      scene.add(bpMesh);
    }

    // Rebar
    if (showRebar) {
      const vBar = getBarData(inputs.verticalBarSize);
      const tBar = getBarData(inputs.tieBarSize);

      // Vertical Bars
      data.verticalBars.forEach(bar => {
        const geom = new THREE.CylinderGeometry(vBar.diameter / 2, vBar.diameter / 2, inputs.pedestalHeight, 8);
        const mat = new THREE.MeshPhongMaterial({ color: 0x3b82f6 });
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(bar.x, inputs.pedestalHeight / 2, bar.y);
        scene.add(mesh);
      });

      // Ties
      data.ties.forEach(tie => {
        // Create a rectangular path for the tie
        const shape = new THREE.Shape();
        const w = tie.length / 2;
        const h = tie.width / 2;
        shape.moveTo(-w, -h);
        shape.lineTo(w, -h);
        shape.lineTo(w, h);
        shape.lineTo(-w, h);
        shape.lineTo(-w, -h);

        const extrudeSettings = {
          steps: 1,
          depth: tBar.diameter,
          bevelEnabled: false,
        };
        
        // Simplified tie as a torus-like structure or 4 cylinders
        const tieGroup = new THREE.Group();
        const mat = new THREE.MeshPhongMaterial({ color: 0x1e40af });
        
        const createSide = (len: number, x: number, z: number, rotY: number) => {
          const geom = new THREE.CylinderGeometry(tBar.diameter / 2, tBar.diameter / 2, len, 8);
          const mesh = new THREE.Mesh(geom, mat);
          mesh.position.set(x, tie.z, z);
          mesh.rotation.z = Math.PI / 2;
          mesh.rotation.y = rotY;
          tieGroup.add(mesh);
        };

        createSide(tie.length, 0, tie.width / 2, 0);
        createSide(tie.length, 0, -tie.width / 2, 0);
        createSide(tie.width, tie.length / 2, 0, Math.PI / 2);
        createSide(tie.width, -tie.length / 2, 0, Math.PI / 2);
        
        scene.add(tieGroup);
      });
    }

    // Anchor Bolts
    if (showBolts) {
      inputs.bolts.forEach(bolt => {
        const totalLen = inputs.boltTotalLength;
        const geom = new THREE.CylinderGeometry(inputs.boltDiameter / 2, inputs.boltDiameter / 2, totalLen, 16);
        const mat = new THREE.MeshPhongMaterial({ color: 0xf97316, shininess: 80 });
        const mesh = new THREE.Mesh(geom, mat);
        
        const topY = inputs.pedestalHeight + inputs.groutThickness + inputs.baseplateThickness + inputs.boltProjection;
        mesh.position.set(bolt.x, topY - totalLen / 2, bolt.y);
        scene.add(mesh);
      });
    }

  }, [inputs, data, showConcrete, showRebar, showBaseplate, showBolts]);

  const setCameraView = (view: 'top' | 'front' | 'side' | 'iso') => {
    if (!cameraRef.current || !controlsRef.current) return;
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    const dist = Math.max(inputs.pedestalLength, inputs.pedestalHeight, inputs.pedestalWidth) * 2;

    switch (view) {
      case 'top':
        camera.position.set(0, dist, 0);
        break;
      case 'front':
        camera.position.set(0, inputs.pedestalHeight / 2, dist);
        break;
      case 'side':
        camera.position.set(dist, inputs.pedestalHeight / 2, 0);
        break;
      case 'iso':
        camera.position.set(dist, dist, dist);
        break;
    }
    controls.target.set(0, inputs.pedestalHeight / 2, 0);
    controls.update();
  };

  return (
    <div className="w-full h-full relative">
      <div ref={containerRef} className="w-full h-full" />
      
      {/* Controls Overlay */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <div className="bg-white/90 backdrop-blur p-2 rounded-lg shadow-md border border-slate-200 flex flex-col gap-2">
          <button onClick={() => setShowConcrete(!showConcrete)} className={`p-2 rounded flex items-center gap-2 text-xs font-medium ${showConcrete ? 'bg-blue-50 text-blue-600' : 'text-slate-500'}`}>
            {showConcrete ? <Eye size={14} /> : <EyeOff size={14} />} Concrete
          </button>
          <button onClick={() => setShowRebar(!showRebar)} className={`p-2 rounded flex items-center gap-2 text-xs font-medium ${showRebar ? 'bg-blue-50 text-blue-600' : 'text-slate-500'}`}>
            {showRebar ? <Eye size={14} /> : <EyeOff size={14} />} Rebar
          </button>
          <button onClick={() => setShowBaseplate(!showBaseplate)} className={`p-2 rounded flex items-center gap-2 text-xs font-medium ${showBaseplate ? 'bg-blue-50 text-blue-600' : 'text-slate-500'}`}>
            {showBaseplate ? <Eye size={14} /> : <EyeOff size={14} />} Baseplate
          </button>
          <button onClick={() => setShowBolts(!showBolts)} className={`p-2 rounded flex items-center gap-2 text-xs font-medium ${showBolts ? 'bg-blue-50 text-blue-600' : 'text-slate-500'}`}>
            {showBolts ? <Eye size={14} /> : <EyeOff size={14} />} Bolts
          </button>
        </div>

        <div className="bg-white/90 backdrop-blur p-2 rounded-lg shadow-md border border-slate-200 flex flex-col gap-2">
          <button onClick={() => setCameraView('top')} className="p-2 hover:bg-slate-100 rounded text-xs font-medium text-slate-600 flex items-center gap-2">
            <Camera size={14} /> Top
          </button>
          <button onClick={() => setCameraView('front')} className="p-2 hover:bg-slate-100 rounded text-xs font-medium text-slate-600 flex items-center gap-2">
            <Camera size={14} /> Front
          </button>
          <button onClick={() => setCameraView('side')} className="p-2 hover:bg-slate-100 rounded text-xs font-medium text-slate-600 flex items-center gap-2">
            <Camera size={14} /> Side
          </button>
          <button onClick={() => setCameraView('iso')} className="p-2 hover:bg-slate-100 rounded text-xs font-medium text-slate-600 flex items-center gap-2">
            <Camera size={14} /> Iso
          </button>
        </div>
      </div>

      <div className="absolute bottom-4 left-4 bg-white/80 backdrop-blur px-3 py-1.5 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-widest border border-slate-200">
        3D Interactive Engine
      </div>
    </div>
  );
};

export default ThreeDView;
