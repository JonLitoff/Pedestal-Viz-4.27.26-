import React, { useState, useRef, useEffect } from 'react';
import { PedestalInputs, CalculatedData } from '../types/pedestal';
import { getBarData } from '../utils/aciData';
import { ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { hapticFeedback, isMobile } from '../utils/mobileFeatures';

interface PlanViewProps {
  inputs: PedestalInputs;
  data: CalculatedData;
}

const PlanView: React.FC<PlanViewProps> = ({ inputs, data }) => {
  const padding = 40;
  const width = 600;
  const height = 600;

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);

  // Scale factor to fit pedestal in the view
  const maxDim = Math.max(inputs.pedestalLength, inputs.pedestalWidth);
  const baseScale = (width - 2 * padding) / maxDim;
  const scale = baseScale * zoom;

  const toPx = (val: number) => val * scale;
  const centerX = width / 2 + pan.x;
  const centerY = height / 2 + pan.y;

  const vBar = getBarData(inputs.verticalBarSize);
  const tBar = getBarData(inputs.tieBarSize);

  // Find the top-left bolt (most negative x and y)
  const topLeftBolt = inputs.bolts.reduce((min, bolt) => 
    (bolt.x < min.x || (bolt.x === min.x && bolt.y < min.y)) ? bolt : min
  , inputs.bolts[0]);

  // Calculate distances from top-left bolt to each rebar
  const rebarDistances = data.verticalBars.map(bar => {
    const dx = bar.x - topLeftBolt.x;
    const dy = bar.y - topLeftBolt.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    return { bar, distance, dx, dy };
  });

  // Filter rebar that are within embedment/3
  const embedmentThird = data.boltEmbedment / 3;
  const showDimension = rebarDistances.filter(r => r.distance <= embedmentThird);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(z => Math.min(Math.max(z * delta, 0.5), 5));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    if (isMobile()) hapticFeedback('light');
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const touch = e.touches[0];
      setIsDragging(true);
      setDragStart({ x: touch.clientX - pan.x, y: touch.clientY - pan.y });
      hapticFeedback('light');
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    const touch = e.touches[0];
    setPan({ x: touch.clientX - dragStart.x, y: touch.clientY - dragStart.y });
  };

  const handleMouseUp = () => setIsDragging(false);
  const handleTouchEnd = () => setIsDragging(false);

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  return (
    <div className="w-full h-full flex flex-col bg-white">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom(z => Math.min(z * 1.2, 5))}
            className="p-1.5 bg-white border border-slate-200 rounded hover:bg-slate-100"
            title="Zoom In"
          >
            <ZoomIn size={16} />
          </button>
          <button
            onClick={() => setZoom(z => Math.max(z * 0.8, 0.5))}
            className="p-1.5 bg-white border border-slate-200 rounded hover:bg-slate-100"
            title="Zoom Out"
          >
            <ZoomOut size={16} />
          </button>
          <button
            onClick={resetView}
            className="p-1.5 bg-white border border-slate-200 rounded hover:bg-slate-100"
            title="Reset View"
          >
            <RotateCcw size={16} />
          </button>
          <span className="text-xs text-slate-500 ml-2">{Math.round(zoom * 100)}%</span>
        </div>
        <span className="text-xs text-slate-400">Scroll to zoom, drag to pan</span>
      </div>
      
      <div 
        className="flex-1 overflow-hidden cursor-grab active:cursor-grabbing"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <svg
          ref={svgRef}
          id="plan-svg"
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full drop-shadow-sm"
          style={{ minWidth: width, minHeight: height }}
        >
        {/* Grid lines (optional) */}
        <defs>
          <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f1f5f9" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />

        {/* Pedestal Outline */}
        <rect
          x={centerX - toPx(inputs.pedestalLength / 2)}
          y={centerY - toPx(inputs.pedestalWidth / 2)}
          width={toPx(inputs.pedestalLength)}
          height={toPx(inputs.pedestalWidth)}
          fill="#f8fafc"
          stroke="#94a3b8"
          strokeWidth="3"
        />

        {/* Baseplate Outline */}
        <rect
          x={centerX - toPx(inputs.baseplateLength / 2)}
          y={centerY - toPx(inputs.baseplateWidth / 2)}
          width={toPx(inputs.baseplateLength)}
          height={toPx(inputs.baseplateWidth)}
          fill="none"
          stroke="#475569"
          strokeWidth="2"
          strokeDasharray="5,5"
        />

        {/* Ties (Top Tie) */}
        {data.ties.length > 0 && (
          <rect
            x={centerX - toPx(data.ties[0].length / 2)}
            y={centerY - toPx(data.ties[0].width / 2)}
            width={toPx(data.ties[0].length)}
            height={toPx(data.ties[0].width)}
            fill="none"
            stroke="#1e40af"
            strokeWidth={toPx(tBar.diameter)}
            rx={toPx(tBar.diameter)}
          />
        )}

        {/* Vertical Rebar */}
        {data.verticalBars.map((bar, idx) => (
          <g key={idx}>
            <circle
              cx={centerX + toPx(bar.x)}
              cy={centerY - toPx(bar.y)}
              r={toPx(vBar.diameter / 2)}
              fill="#3b82f6"
              stroke="#1d4ed8"
              strokeWidth="1"
            />
            {/* Label for corner bars or every few bars */}
            {(idx === 0 || idx === data.verticalBars.length - 1) && (
              <text
                x={centerX + toPx(bar.x)}
                y={centerY - toPx(bar.y) - toPx(vBar.diameter) - 5}
                textAnchor="middle"
                fontSize="10"
                className="fill-slate-500 font-bold"
              >
                {vBar.size}
              </text>
            )}
          </g>
        ))}

        {/* Anchor Bolts */}
        {inputs.bolts.map((bolt, idx) => (
          <g key={idx}>
            {/* Bolt Body */}
            <circle
              cx={centerX + toPx(bolt.x)}
              cy={centerY - toPx(bolt.y)}
              r={toPx(inputs.boltDiameter / 2)}
              fill="#f97316"
              stroke="#ea580c"
              strokeWidth="1"
            />
            {/* Centerlines */}
            <line
              x1={centerX + toPx(bolt.x) - 10}
              y1={centerY - toPx(bolt.y)}
              x2={centerX + toPx(bolt.x) + 10}
              y2={centerY - toPx(bolt.y)}
              stroke="#ea580c"
              strokeWidth="0.5"
              strokeDasharray="2,2"
            />
            <line
              x1={centerX + toPx(bolt.x)}
              y1={centerY - toPx(bolt.y) - 10}
              x2={centerX + toPx(bolt.x)}
              y2={centerY - toPx(bolt.y) + 10}
              stroke="#ea580c"
              strokeWidth="0.5"
              strokeDasharray="2,2"
            />
          </g>
        ))}

        {/* Dimension Lines */}
        {/* Pedestal Length */}
        <g className="dimensions">
          <line
            x1={centerX - toPx(inputs.pedestalLength / 2)}
            y1={centerY + toPx(inputs.pedestalWidth / 2) + 20}
            x2={centerX + toPx(inputs.pedestalLength / 2)}
            y2={centerY + toPx(inputs.pedestalWidth / 2) + 20}
            stroke="black"
            strokeWidth="1"
          />
          <text
            x={centerX}
            y={centerY + toPx(inputs.pedestalWidth / 2) + 35}
            textAnchor="middle"
            fontSize="12"
            className="fill-black font-medium"
          >
            L = {inputs.pedestalLength}"
          </text>
        </g>

        {/* Pedestal Width */}
        <g className="dimensions">
          <line
            x1={centerX + toPx(inputs.pedestalLength / 2) + 20}
            y1={centerY - toPx(inputs.pedestalWidth / 2)}
            x2={centerX + toPx(inputs.pedestalLength / 2) + 20}
            y2={centerY + toPx(inputs.pedestalWidth / 2)}
            stroke="black"
            strokeWidth="1"
          />
          <text
            x={centerX + toPx(inputs.pedestalLength / 2) + 35}
            y={centerY}
            textAnchor="middle"
            fontSize="12"
            transform={`rotate(90, ${centerX + toPx(inputs.pedestalLength / 2) + 35}, ${centerY})`}
            className="fill-black font-medium"
          >
            W = {inputs.pedestalWidth}"
          </text>
        </g>

        {/* Bolt to Rebar Dimensions (if within embedment/3) */}
        {showDimension.map((item, idx) => (
          <g key={idx}>
            <line
              x1={centerX + toPx(topLeftBolt.x)}
              y1={centerY - toPx(topLeftBolt.y)}
              x2={centerX + toPx(item.bar.x)}
              y2={centerY - toPx(item.bar.y)}
              stroke="#dc2626"
              strokeWidth="1"
              strokeDasharray="3,3"
            />
            <text
              x={(centerX + toPx(topLeftBolt.x) + centerX + toPx(item.bar.x)) / 2}
              y={(centerY - toPx(topLeftBolt.y) + centerY - toPx(item.bar.y)) / 2 - 5}
              textAnchor="middle"
              fontSize="9"
              className="fill-red-600 font-bold"
            >
              {item.distance.toFixed(2)}"
            </text>
          </g>
        ))}

        {/* Legend */}
        <g transform={`translate(${width - 120}, 20)`}>
          <rect width="110" height="80" fill="white" fillOpacity="0.8" stroke="#e2e8f0" rx="4" />
          <text x="5" y="15" fontSize="10" fontWeight="bold" className="fill-slate-700">LEGEND</text>
          <circle cx="10" cy="30" r="4" fill="#3b82f6" />
          <text x="20" y="33" fontSize="9" className="fill-slate-600">Vertical: {vBar.size}</text>
          <rect x="6" y="42" width="8" height="2" fill="#1e40af" />
          <text x="20" y="48" fontSize="9" className="fill-slate-600">Tie: {tBar.size}</text>
          <circle cx="10" cy="60" r="4" fill="#f97316" />
          <text x="20" y="63" fontSize="9" className="fill-slate-600">Bolt: {inputs.boltDiameter}"</text>
        </g>
      </svg>
      </div>
    </div>
  );
};

export default PlanView;
