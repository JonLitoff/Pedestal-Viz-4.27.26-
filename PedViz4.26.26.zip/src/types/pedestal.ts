export interface BarData {
  size: string;
  diameter: number; // inches
  area: number; // sq inches
}

export interface AnchorBolt {
  x: number;
  y: number;
}

export interface PedestalInputs {
  // Pedestal Dimensions
  pedestalLength: number;
  pedestalWidth: number;
  pedestalHeight: number;

  // Steel Baseplate
  baseplateLength: number;
  baseplateWidth: number;
  baseplateThickness: number;

  // Grout
  groutThickness: number;

  // Reinforcement
  verticalBarSize: string;
  tieBarSize: string;
  barsAlongLength: number; // includes corner bars
  barsAlongWidth: number; // includes corner bars
  clearance: number; // to outer edge of vertical bar
  topTieClearance: number; // from top of concrete to center of first tie
  tieSpacing: number; // center-to-center

  // Anchor Bolts
  bolts: AnchorBolt[];
  boltTotalLength: number;
  boltProjection: number;
  boltDiameter: number;
}

export interface CalculatedData {
  verticalBars: { x: number; y: number; z: number }[];
  ties: { z: number; width: number; length: number }[];
  boltEmbedment: number;
  warnings: string[];
}
